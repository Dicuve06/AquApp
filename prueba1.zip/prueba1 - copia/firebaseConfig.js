import React, {useEffect, useState} from "react";
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getDatabase, ref, set, get, child, update, onValue } from "firebase/database";

//This was definitely the most difficult part of the coding because I had never before experimented with databases

const firebaseConfig = {
  apiKey: "AIzaSyDmVrnbq06fxz6uFGJN-emerjl8uas-nBI",
  authDomain: "aquapp-42347.firebaseapp.com",
  databaseURL: "https://aquapp-42347-default-rtdb.firebaseio.com",
  projectId: "aquapp-42347",
  storageBucket: "aquapp-42347.appspot.com",
  messagingSenderId: "115930135694",
  appId: "1:115930135694:web:65c6f7662d3b5937bc1ddf",
  measurementId: "G-574H9Q68Z9"
};

const app = initializeApp(firebaseConfig);
const database = getDatabase(app);

function writeUserData(userId, name, email){
  const db = getDatabase(app);
  const reference = ref(db, 'users/' + userId);
  

  set(reference, {
      username: name,
      email: email,
      score: 10,
});
}

let scoringExecuted = false;

function scoring(importe) {
  let scoringExecuted = false;
  if (!scoringExecuted) {
    const db = getDatabase();
    const userScoreRef = ref(db, `users/score`);
    onValue(userScoreRef, (snapshot) => {
      const currentScore = snapshot.val();
      if (typeof currentScore === 'number' && !isNaN(currentScore)) {
        const newScore = currentScore + importe;
        //Since this function took so long, I worte a lote of consolelog's to know which steps where done and what was still pendng. 
        console.log('hii');
        set(userScoreRef, newScore)
          .then(() => {
            scoringExecuted = true;
            console.log(`Score updated successfully. New score: ${newScore}`);
          })
          .catch((error) => {
            console.error(`Error updating score`, error);
          });
          console.log('hi');
      } else {
        console.error(`Invalid score data. Expected number, got:`, typeof currentScore);
        console.log('Current score value:', currentScore);
      }
    }, {
      onlyOnce: true
    });
  }
}

//This function  was orignally thought to get each user's individual score. Now it enables me instead to get the community score.
export const fetchUserScore = async () => {
  const dbRef = ref(database, 'users/score');
  try {
    const snapshot = await get(dbRef);
    if (snapshot.exists()) {
      return snapshot.val();
    } else {
      console.log("Nop");
      return null;
    }
  } catch (error) {
    console.error("Error fetching user score:", error);
    throw error;
  }
};

export {app, scoring, writeUserData};