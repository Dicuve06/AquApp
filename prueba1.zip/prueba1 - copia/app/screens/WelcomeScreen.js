import React from 'react';
import { ImageBackground, StyleSheet, View, Image, TouchableOpacity, Platform, Dimensions} from 'react-native';
import { useDeviceOrientation } from '@react-native-community/hooks';

//This is the home screen, this was the most complex on visual terms because different screens had different ratios.
//That made percentages not so reliable, so after a lot of mistakes, I discovered that if I only used the percentage to determine the one of the two factors (width or length)
//and then wrote the other in terms of the first one by multiplying it by the image's ratio, then the appearence would always remain the same. 

function WelcomeScreen({navigation}) {
    const landscape = useDeviceOrientation();
    const Wwidth = Dimensions.get('window').width;
    return (
        <ImageBackground 
        style ={styles.background} source ={{ uri: 'https://i.postimg.cc/k43bK8gk/Background.png'}}
        >
            <TouchableOpacity style = {{
            position: Platform.OS === 'android' ? 'absolute' : 'relative',
            width: landscape === 'landscape' ? Platform.OS === 'android' ? '27%': '25%' : Platform.OS === 'android' ? '60%' : '60%',
            height: landscape === 'landscape' ? Platform.OS === 'android' ? Wwidth*0.27*0.6 : Wwidth*0.25*0.6 : Platform.OS === 'android' ? Wwidth*0.6*0.6: Wwidth*0.6*0.6,
            top: landscape === 'landscape' ? '10%' : Platform.OS === 'android' ? '23%' : '25%',
            right : landscape === 'landscape' ? Platform.OS === 'android' ? '36%' : '-37.8%' : Platform.OS === 'android' ?'19%': '-22%',
            }}
            onPress={()=> navigation.navigate("Actuar")}>
            <Image style = {{
            height: '100%',
            }}
            source = {{uri: 'https://i.postimg.cc/HxWwcdN5/UpArrow.png'}}></Image> 
            </TouchableOpacity>
            <TouchableOpacity style = {{
            position: Platform.OS === 'android' ? 'absolute' : 'relative',
            width: landscape === 'landscape' ? Platform.OS === 'android' ? '22%' : '20%' : Platform.OS === 'android' ? '50%' : '48%',
            height: landscape === 'landscape' ? Platform.OS === 'android' ? Wwidth*0.22*1.09 : Wwidth*0.20*1.09: Platform.OS === 'android' ? Wwidth*0.5*1.09: Wwidth*0.48*1.09,
            left: landscape === 'landscape' ? Platform.OS === 'android' ? '51%' : '50%' : Platform.OS === 'android' ? '50%': '47%',
            top: landscape === 'landscape' ? Platform.OS === 'android' ? '48%': '17%' : Platform.OS === 'android' ? '51%' : '30%',
            }}
            onPress={()=> navigation.navigate("Reportar")}>
            <Image style = {{
            height: '100%',
            }}
            source = {{uri: 'https://i.postimg.cc/wM3RdkfR/Right-Arrow.png'}}></Image>
            </TouchableOpacity>
            <TouchableOpacity style = {{
            position: Platform.OS === 'android' ? 'absolute' : 'relative',
            width: landscape === 'landscape' ? Platform.OS === 'android' ? '15%' : '14%' : Platform.OS === 'android' ? '34%' : '32%',
            height: landscape === 'landscape' ? Platform.OS === 'android' ? Wwidth*0.15*1.75 : Wwidth*0.14*1.75 : Platform.OS === 'android' ? Wwidth*0.34*1.75 : Wwidth*0.32*1.75,
            right: landscape === 'landscape' ? Platform.OS === 'android' ? '55%' : '-30%' : Platform.OS === 'android' ? '63%': '-5%',
            top: landscape === 'landscape' ? Platform.OS === 'android' ? '42%' : '-39%' : Platform.OS === 'android' ? '46%' :'2%',
            }}
            onPress={()=> navigation.navigate("Informar")}>
            <Image style = {{
            height: '100%',
            }}
            source = {{uri: 'https://i.postimg.cc/4yfwvpF8/Left-Arrow.png'}}></Image>
            </TouchableOpacity>  
            <TouchableOpacity style = {{
            position: Platform.OS === 'android' ? 'absolute' : 'relative',
            width: landscape === 'landscape' ? Platform.OS === 'android' ? '11%': '11%' : Platform.OS === 'android' ? '30%' : '30%',
            height: landscape === 'landscape' ? Platform.OS === 'android' ? Wwidth*0.11*1.65: Wwidth*0.11*1.65 :  Platform.OS === 'android' ? Wwidth*0.3*1.65 : Wwidth*0.3*1.65,
            top: landscape === 'landscape' ? Platform.OS === 'android' ? '35%' : '-100%' : Platform.OS === 'android' ? '38%': '-31%',
            right: landscape === 'landscape' ? Platform.OS === 'android' ? '44%': '-44.3%' : Platform.OS === 'android' ? '35%': '-35%',
            }}
            onPress={()=> navigation.navigate("Contemplar")}>
           <Image style = {{
            height: '100%',
            }}
            source = {{uri: 'https://i.postimg.cc/MpN3QP2t/GranGota.png'}}></Image>
            </TouchableOpacity>
        </ImageBackground>
    );
}

const styles = StyleSheet.create({
    background: {
        flex: 1,
        //justifyContent: 'center',
        //alignItems: 'center' 
    },
})

export default WelcomeScreen;