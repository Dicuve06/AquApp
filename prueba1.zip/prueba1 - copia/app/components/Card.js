import React, { useEffect, useState } from "react";
import { View, StyleSheet, Image, Text, TextInput, TouchableOpacity, Dimensions, Alert, SafeAreaView } from 'react-native';
import { useDeviceOrientation } from '@react-native-community/hooks';
import { useNavigation } from '@react-navigation/native';
import { AutoSizeText, ResizeTextMode } from 'react-native-auto-size-text';
import { scoring } from "../../firebaseConfig";

//This is the Card component wich creates all the cards in the 'QuePuedoHacerHoyScreen.js'

function Card({ title, value, image }, props) {
    const landscape = useDeviceOrientation();
    const navigation = useNavigation();
    const Wwidth = Dimensions.get('window').width;
    const [size, setSize] = useState(20);
    const [viewHeight, setViewHeight] = useState(0);
    const [textHeight, setTextHeight] = useState(0);

    useEffect(() => {
        if (textHeight > viewHeight) {
            setSize(size + 1);
        }
    }, [textHeight]);

    //This is the configuration for the alert and therefore for either cancelling the action or undertaking it and adding its value to the community volume of water saved. 
    const handlePress = () => {
        Alert.alert(
            "Confirmar Acción",
            `La acción aportará ${value} litros al conteo general.`,
            [
                {
                    text: "Regresar",
                    style: "destructive",
                },
                {
                    text: "Claro!",
                    fontWeight: "bold",
                    onPress: () => {
                        const numericValue = parseFloat(value);
                        scoring(numericValue);
                        navigation.navigate('Actuar');
                    },
                },
            ],
            { cancelable: false }
        );
    };
//Visual design of the card component. 
    return (
        <TouchableOpacity onPress={handlePress}>
            <SafeAreaView style={[
                styles.card,
                { width: landscape === 'landscape' ? '90%' : '95%' },
                { height: landscape === 'landscape' ? Wwidth * 0.95 * 0.2 : Wwidth * 0.95 * 0.40 },
                { left: '5%' }
            ]}>
                <Text
                    style={{
                        flex: 1,
                        // fontSize: 80,
                        // lineHeight: 20 + title.length,
                        numberOfLines: 5,
                        fontSize: landscape === 'landscape' ? Wwidth * 0.042 : Wwidth * 0.07,  // Adjust font size
                        width: '76%',
                        color: '#111111',
                        marginRight: '20%',
                        marginLeft: '3%',
                        top: '0%',
                    }}
                >
                    {title}
                </Text>
                <View style={{
                    width: '30%',
                    left: '52%',
                    bottom: '20%'
                }}>
                    <Text style={{
                        position: 'absolute',
                        fontSize: landscape === 'landscape' ? 15 : 15,
                        fontWeight: 'bold',
                        textAlign: 'center',
                        top: landscape === 'landscape' ? '85%' : '80%',
                        left: landscape === 'landscape' ? '87.5%' : '75%',
                    }}>
                        {value} L
                    </Text>
                </View>
                <Image style={{
                    position: 'absolute',
                    left: landscape === 'landscape' ? '85%' : '78%',
                    top: landscape === 'landscape' ? '3%' : '10%',
                    width: landscape === 'landscape' ? '11%' : '20%',
                    height: landscape === 'landscape' ? Wwidth * 0.08 * 1.5 : Wwidth * 0.20 * 1.1,
                }}
                    source={{
                        uri: image,
                    }} />
            </SafeAreaView>
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    card: {
        borderRadius: 20,
        borderWidth: 8,
        borderColor: '#000099',
        borderTopLeftRadius: 0,
        backgroundColor: '#66CCFF',
        marginTop: 15,
        paddingTop: 5,
    }
})

export default Card;
