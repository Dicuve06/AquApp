import React from 'react';
import { ImageBackground, StyleSheet, Platform, TouchableOpacity, Image, StatusBar, ScrollView, Text, Dimensions } from 'react-native';
import { useDeviceOrientation } from '@react-native-community/hooks';

//This is the screen of the article

function PorQueScreen({navigation}) {
    const landscape = useDeviceOrientation();
    const WHeight = Dimensions.get('window').height;
    //USE THIS INSTEAD OF HEIGHT 
    const WWidth = Dimensions.get('window').width;
    return (
        <ImageBackground style = {styles.background} source={{uri:'https://i.postimg.cc/wMGHr5Kj/Reporta-Fuga-BG.png'}}>
        <TouchableOpacity style = {{
                width : landscape === 'landscape' ? '15%' : '33%',
                height: landscape === 'landscape' ? '25%' : '15%',
                left: '3.5%',
                top : Platform === 'android' ? StatusBar.currentHeight: '5%',
            }}
            onPress={()=> navigation.navigate("Origen")}>
            <Image style = {{
                height : '100%'
                }}
                source = {{uri: 'https://i.postimg.cc/bvdtkGfc/Return-Arrow.png'}}/>
        </TouchableOpacity>

        <ScrollView style = {{
            top: '5%',
        }}>
            <Text style = {{
                width: '90%',
                left: '5%',
                top: '0%',
                fontSize: 25,
                textAlign: 'justify',
                fontStyle: 'normal',
                fontFamily: 'Times New Roman',
                paddingBottom: 10,
            }} >
            La realidad de la crisis del agua en México es mucho más compleja de lo que parece. Si bien nosotros podemos llegar a incurrir varias veces en faltas de manejo del agua, no somos los únicos culpables. El gobierno y las compañías deben mejorar sustancialmente en cuanto a su manejo del agua para que…. Vayamos por partes: 
            </Text>
            <Image style = {{
            height: landscape === 'landscape' ? Platform.OS == 'android' ? WWidth*0.22*(187/153) : WWidth*0.145*(187/153) : Platform.OS == 'android' ? WWidth*0.42*(187/153) : WWidth*0.34*(187/153),
            width: landscape === 'landscape' ? Platform.OS === 'android' ? '22%':'14.5%' : Platform.OS === 'android' ? '42%' : '36%',
            position: 'relative',
            right: landscape === 'landscape' ? Platform.OS === 'android' ? '-75%': '-81%' : Platform.OS === 'android' ? '-56%':'-62%',
            top: landscape === 'landscape' ? Platform.OS === 'android' ? '0%' : '0%' : Platform.OS === 'android' ? '-0.55%':'-0.5%',
            }}
            source = {{uri:'https://i.postimg.cc/GhFQ1j3d/gob-preview-rev-1.png'}}>
            </Image>
            <Text style = {styles.heading}>
            Gobierno:
            </Text>
            <Text style = {styles.relleno}>
            En la CDMX, el día cero, momento en el cuál una ciudad deja de poder abastecer a sus 
            ciudadanos de agua, ya fue sobrepasado y las consecuencias son evidentes (hospitales sin 
            agua, pozos contaminados, cortes de agua en ciertas colonias, racionamiento de los recursos 
            hídricos…). Se estima que el 30-40% del agua se pierde en fugas. Esto es inadmisible.
            </Text>
            <Text style = {styles.relleno}>
            Indudablemente, la gente debe reducir su propio consumo hídrico, pero el gobierno debe 
            proporcionar la infraestructura adecuada para que estas medidas tengan un efecto. La escasez 
            de agua es un problema que afecta a toda la sociedad, por lo que concierne a las 
            organizaciones gubernamentales. 
            </Text>
            <Text style = {styles.relleno}>
            Sin embargo, no resolveremos nada simplemente por culpabilizar al gobierno. Lo que 
            podemos hacer es exigir y apoyar a la reparación de esta infraestructura. Una simple llamada 
            para reportar una fuga puede ser la diferencia entre que se desperdicie agua por cinco días o 
            por dos horas. Tan solo una gota de agua por segundo equivale a 30 litros desperdiciados al 
            día, cuando son miles de fugas se convierten en 30,000 litros en un solo día. Si ves una fuga 
            de agua en la calle, tan sólo toma cinco minutos reportarla. Sacmex y Logitel atienden 
            llamadas 24/7 y sólo requieren la siguiente información:  
            </Text>
            <Text style = {styles.viñeta}>
            • Ubicación 
            </Text>
            <Text style = {styles.viñeta}>
            • Magnitud de la fuga 
            </Text>
            <Text style = {styles.relleno}>
            Son dos simples datos que ayudan a salvar miles de toneladas de agua. Los números  
            telefónicos se encuentran en la sección de reportar fugas.
            </Text>
            <Text style = {styles.relleno}>
            Es imperativo mencionar que el gobierno no ha manejado correctamente la crisis hídrica. Si 
            en octubre de 2024 estamos mejor en cuánto a nivel de abasto de presas, es dado a que las 
            lluvias aumentaron no porque el gobierno haya resuelto el problema. Los embalses de agua 
            se recuperaron, pero es más que evidente que el trabajo de la CONAGUA ha sido insuficiente. 
            Las inundaciones en la zona metropolitana de la Ciudad de México son prueba de la falta de 
            infraestructura para el manejo del agua.  
            </Text>
            <Text style = {styles.relleno}>
            El problema con la planificación del gobierno es que no se implementan planes a largo plazo 
            para reducir el desperdicio de agua, sino que intenta resolver la situación cuando ya se 
            convirtió en una crisis. Además, no hay control alguno sobre las empresas que se asientan en 
            zonas con escasos recursos hídricos que llegan a extraer miles de litros por segundo mientras 
            la población no puede abastecerse del líquido vital. Si bien siempre ha existido la publicidad 
            de cuidar el agua, esa ha sido la principal acción del gobierno. Aunado a esto, en plena crisis 
            hídrica, en la alcaldía Benito Juárez se contaminó uno de los pozos de agua subterráneos. 
            También es muy sonado el caso de Chalco, donde el gobierno abandonó a los habitantes y no 
            lidió con las inundaciones de la zona.
            </Text>
            <Text style = {styles.relleno}>
            De la misma manera, muchas entidades han sufrido una crisis hídrica. En Guadalajara en 
            2021 la mala planeación urbana dejó sin agua al 4.5% del área metropolitana de Guadalajara 
            por 6 meses. En Monterrey, zona árida que depende principalmente del río Panuco, el 
            gobierno no pudó evitar la situación crítica que se sufrió el año pasado. Con temperaturas de 
            40° en una ciudad con 5.3 millones de habitantes, el día cero llegó y llegaron a faltar inclusive 
            botellas de agua potable. Dada la poca previsión de las instituciones responsables del manejo 
            del agua y del gobierno estatal, solo se podía suministrar durante 6 horas agua potable. Las 
            reservas estaban prácticamente vacías, con niveles de 5% tras una sequía sin precedentes. 
            Todo esto es producto no solo de la crisis climática sino  también de la negligencia 
            gubernamental.  
            </Text>
            <Text style = {styles.relleno}>
            Aún con todos estos factores que exigían una mejora del sistema, especialmente cuando se 
            habla de fugas, no se hizo ningún plan de infraestructura significativo. 
            </Text>
            <Text style = {styles.relleno}>
            El Programa Nacional Hídrico 2020-2024 promete lo siguiente: 
            </Text>
            <Text style = {styles.viñeta}>
            ‘2.1.1 Conservar, rehabilitar y modernizar la infraestructura hidroagrícola (D.R., U.R. y D.T.T.)’
            </Text>
            <Text style = {styles.relleno}>
            Sin embargo, la proporción de fugas sigue siendo la misma y las acciones en el campo 
            mexicano han sido principalmente de mantenimiento, dejando de lado la modernización del 
            sector agrícola y por consiguiente una mejora en cuanto a la eficiencia en el uso del agua. 
            Por si no fuera suficiente, apenas las lluvias favorecieron al sistema Cutzamala, el tema 
            volvió a pasar a segundo plano.  
            </Text>
            <Image style = {{
            height: landscape === 'landscape' ? Platform.OS === 'android' ? WWidth*(0.22)*(295/286) : WWidth*(0.15)*(295/286) :  Platform.OS === 'android' ?  WWidth*(0.38)*(295/286) : WWidth*(0.35)*(295/286),
            width: landscape === 'landscape' ? Platform.OS === 'android' ? '22%':'15%' : Platform.OS === 'android' ? '38%': '35%',
            position: 'relative',
            left:  landscape === 'landscape' ? Platform.OS === 'android' ? '75%':'81%' : Platform.OS === 'android' ? '60%':'62.5%',
            top: landscape === 'landscape' ? Platform.OS === 'android' ? '-1.5%':'-1.4%' :  Platform.OS === 'android' ? '-1.85%' : '-1.4%',

            }}
            source = {{uri:'https://i.postimg.cc/C5mxjtHw/empresa-preview-rev-1.png'}}>
            </Image>
            <Text style = {styles.heading2}>
            Empresas:
            </Text>
            <Text style = {styles.rellenoPH}>
            ¿Ahora, cuál es el papel de las empresas en esta crisis del agua? Frecuentemente oímos cómo 
            se denuncia a las refresqueras por utilizar una parte significativa del agua del país y cómo 
            son poco responsables con su cuidado del medio ambiente. Sin embargo, no son sólo las 
            refresqueras las que contribuyen al despilfarro de agua, sino que también influyen en la crisis 
            las empresas del sector textil, tecnológico, ganadero, etc.   
            </Text>
            <Text style = {styles.rellenoPH}>
            El motivo por el cual el rol de las empresas es menos evidente ante nuestros ojos es porque, 
            al consumir, sólo vemos el producto terminado y pocas veces pensamos en el despilfarro que 
            el proceso de producción implica. Por ejemplo:   
            </Text>
            <Text style = {styles.viñeta2}>
            • Un litro de refresco toma 2.5 litros de agua 
            </Text>
            <Text style = {styles.viñeta2}>
            • Un litro de cerveza toma 4 litros de agua 
            </Text>
            <Text style = {styles.viñeta2}>
            • Una taza de café tostado requiere 140L 
            </Text>
            <Text style = {styles.viñeta2}>
            • Un litro de leche de vaca requiere 600L  
            </Text>
            <Text style = {styles.rellenoPH}>
            Claramente las empresas no anuncian estos gastos enormes de agua pero ahora que los 
            conoces, puedes tomar decisiones conscientes al respecto. Uno de los cambios más grandes 
            que debemos emprender es el de  disminuir nuestro consumo de carne y productos derivados 
            de los animales. La ganadería requiere mucha agua para criar a los animales.  
            </Text>
            <Text style = {styles.viñeta2}>
            • Un kilo de carne vacuna toma 15400L 
            </Text>
            <Text style = {styles.viñeta2}>
            • Un kilo de carne porcina toma 4800L 
            </Text>
            <Text style = {styles.viñeta2}>
            • Un kilo de carne de pollo toma 4325L 
            </Text>
            <Text style = {styles.viñeta2}>
            • Un kilo de soya toma 1500L  
            </Text>
            <Text style = {styles.rellenoPH}>
            Todos estos productos que requieren un gran consumo de agua son los que construyen nuestra 
            HUELLA VIRTUAL HÍDRICA. Este término es un homólogo a la huella ecológica, la cual 
            mide el impacto de nuestras acciones en CO2. Mientras tanto, la huella virtual hídrica mide 
            cuánta agua utilizamos al año.   
            </Text>
            <Text style = {styles.rellenoPH}>
            Una de las industrias que consume más agua pero que no se tiene conciencia acerca de su 
            consumo es la industria textil. Las prendas que utilizamos requieren una gran cantidad de 
            agua para ser producidas. Específicamente, el algodón, requiere mucha agua para ser 
            procesado y utilizarlo en camisas, blusas, pantalones, calcetines, etc.
            </Text>
            <Text style = {styles.rellenoPH}>
            AquApp tiene como objetivo reducir mas no cortar completamente el consumo de estos 
            productos.
            </Text>
            <Text style = {styles.rellenoPH}>
            La única manera en la cual las empresas responden a las exigencias del consumidor es si 
            estos cambian su consumo. No es casualidad que ahora en ciertas ciudades, los restaurantes 
            proporcionen popotes biodegradables, o que se hayan prohibido las bolsas de plástico. Solo 
            podemos crear grandes cambios si modificamos nuestro estilo de vida. Si bien puede parecer 
            extremadamente idealista, es la base del progreso. 
            </Text>
            <Text style = {{
                width: '90%',
                left: '5%',
                top: Platform.OS === 'android' ? '-2.5%': '-1.1%',
                fontSize: 40,
                paddingTop: 0,
                textAlign: 'justify',
                fontStyle: 'normal',
                fontFamily: 'Times New Roman',
                paddingBottom:  Platform.OS === 'android' ? 75:0,
            }}>
            Seres 
            </Text>
            <Text style = {{width: '90%',
                left: '5%',
                top: Platform.OS === 'android' ? '-3.2%': '-1.1%',
                fontSize: 40,
                paddingTop: 0,
                textAlign: 'justify',
                fontStyle: 'normal',
                fontFamily: 'Times New Roman',
                paddingBottom:  Platform.OS === 'android' ? 75:0,}}>
            Humanos: 
            </Text>
            <Image style = {{
            height: landscape === 'landscape' ? Platform.OS === 'android' ? WWidth*(0.45)*(173/295) : WWidth*(0.3)*(173/295) : Platform.OS === 'android' ? WWidth*(0.65)*(173/295) : WWidth*(0.55)*(173/295),
            width: landscape === 'landscape' ? Platform.OS === 'android' ?'45%':'30%' : Platform.OS === 'android' ? '65%':'55%',
            position: 'relative',
            right: landscape === 'landscape' ? Platform.OS === 'android' ? '-50%':'-60%' : Platform.OS === 'android' ? '-33%' : '-40%',
            top: landscape === 'landscape' ? Platform.OS === 'android' ? '-7%': '-4%' :  Platform.OS === 'android' ? '-5.4%' :'-2.8%',

            }}
            source = {{uri:'https://i.postimg.cc/NMQtpD0F/people-preview-rev-1.png'}}>
            </Image>
            <Text style = {styles.relleno3}>
            No podemos deslindarnos de nuestra responsabilidad; también debemos cambiar nuestros 
            hábitos para combatir la escasez de agua. Al final del día, es nuestro sobreconsumo el cual 
            nos ha llevado hasta este punto. 
            </Text>
            <Text style = {styles.relleno3}>
            Debemos reducir el uso excesivo de agua y dejar de tomarla por sentado, este es el propósito 
            de AquApp. Si bien no es fácil cambiar nuestros hábitos de consumo de la noche a la mañana, 
            todos podemos hacer una pequeña acción cada día. AquApp no tiene como objetivo que un 
            solo individuo cambie todo el sistema, sino que busca informar a la población mexicana para 
            que todos hagamos un pequeño cambio cada día. Las pequeñas acciones son el inicio de las 
            transformaciones que la sociedad necesita. 
            </Text>
            <Text style = {{
            width: '90%',
            left: '5%',
            top: Platform.OS === 'android' ? '-4%' : '-2%',
            fontSize: 40,
            paddingTop: 0,
            textAlign: 'justify',
            fontStyle: 'normal',
            fontFamily: 'Times New Roman',
            paddingBottom:  Platform.OS === 'android' ? 75:0,
            }}>Referencias:</Text>
            <Text style = {{
                width: '90%',
                left: '5%',
                top: Platform.OS === 'android' ? '-4.5%':'-1.9%',
                fontSize: 25,
                textAlign: 'justify',
                fontStyle: 'normal',
                fontFamily: 'Times New Roman',
                paddingBottom: 10,
            }}>Estos sitios fueron utilizados para la contabilización de los hábitos y la producción de este 
            artículo: </Text>
            <Text style = {styles.biblio}>
            Brooks, D. (2022, July 18). “A Monterrey le llegó el día cero”: la grave crisis de falta de agua que vive la segunda ciudad más poblada de México. BBC News Mundo. 
https://www.bbc.com/mundo/noticias-america-latina-61917457 
            </Text>
            <Text style = {styles.biblio}>
            Del Agua, C. N. (n.d.). Programa Nacional Hídrico 2020-2024. gob.mx. 
https://www.gob.mx/conagua/articulos/consulta-para-el-del-programa-nacional-hidrico
2019-2024-190499  
            </Text>
            <Text style = {styles.biblio}>
            La crisis hídrica en Monterrey, una alerta para otras zonas del país. (n.d.). 
https://www.puec.unam.mx/index.php/component/content/article/2183-la-crisis-hidrica-en
monterrey-una-alerta-para-otras-zonas-del-pais.html?catid=59&Itemid=101   
            </Text>
            <Text style = {styles.biblio}>
            Ocampo, O. (2024, July 4). El fantasma del “día cero” IMCO. https://imco.org.mx/el-fantasma
del-dia-cero/  
            </Text>
            <Text style = {styles.biblio}>
            Owen, J. (2010, April 26). Pet food sucking up U.S. water. Culture. 
https://www.nationalgeographic.com/culture/article/100423-pet-food-water-footprint   
            </Text>
            <Text style = {styles.biblio}>
            Roa, M. M. (2022, September 6). Más de 15.000 litros de agua por cada kg de carne de res. 
Statista Daily Data. https://es.statista.com/grafico/8316/gasto-de-agua-de-alimentos/ 
            </Text>
            <Text style = {styles.biblio}>
            Tozzini, L., Pannunzio, A., & Soria, P. T. (2021). Water footprint of soybean, maize and wheat in Pergamino, Argentina. Agricultural Sciences, 12(03), 305–323. 
https://doi.org/10.4236/as.2021.123020
            </Text>
            <Text style = {styles.biblio}>
            What’s your water footprint: Water Footprint Calculator home page. (2022, July 6). Water 
Footprint Calculator. https://watercalculator.org/   
            </Text>
            <Text style = {{
                paddingBottom: 100,
            }}></Text>

        </ScrollView>
        </ImageBackground>
    );
}

const WHeight = Dimensions.get('window').height;
const styles = StyleSheet.create({
    background: {
        flex: 1,
        //justifyContent: 'center',
        //alignItems: 'center' 
    },
    relleno: {
        width: '90%',
        left: '5%',
        top: Platform.OS === 'android' ? '-1.7%':'-1%',
        fontSize: 25,
        textAlign: 'justify',
        fontStyle: 'normal',
        fontFamily: 'Times New Roman',
        paddingBottom: 10,
    },
    rellenoPH:{
        width: '90%',
        left: '5%',
        top: Platform.OS === 'android' ? '-2.9%':'-1.9%',
        fontSize: 25,
        textAlign: 'justify',
        fontStyle: 'normal',
        fontFamily: 'Times New Roman',
        paddingBottom: 10,
    },
    relleno3:{
        width: '90%',
        left: '5%',
        top: Platform.OS === 'android' ? '-5%' : '-2.4%',
        fontSize: 25,
        textAlign: 'justify',
        fontStyle: 'normal',
        fontFamily: 'Times New Roman',
        paddingBottom: 10,
    },
    heading: {
        width: '90%',
        left: '5%',
        top: '-1.1%',
        fontSize: 40,
        paddingTop: 0,
        textAlign: 'justify',
        fontStyle: 'normal',
        fontFamily: 'Times New Roman',
        paddingBottom:  Platform.OS === 'android' ? 75:0,
    },
    heading2: {
        width: '90%',
        left: '5%',
        top: Platform.OS ==='android' ? '-2.3%' :'-2%',
        fontSize: 40,
        paddingTop: 0,
        textAlign: 'justify',
        fontStyle: 'normal',
        fontFamily: 'Times New Roman',
        paddingBottom:  Platform.OS === 'android' ? 75:0,
    },
    heading3: {
        width: '90%',
        left: '5%',
        top: '-1%',
        fontSize: 40,
        paddingTop: 0,
        textAlign: 'justify',
        fontStyle: 'normal',
        fontFamily: 'Times New Roman',
        paddingBottom:  Platform.OS === 'android' ? 75:0,
    },
    viñeta: {
        width: '80%',
        left: '15%',
        top: Platform.OS === 'android' ? '-1.8%':'-1%',
        fontSize: 20,
        textAlign: 'justify',
        fontStyle: 'normal',
        fontFamily: 'Times New Roman',
        paddingBottom:5,
    },
    viñeta2: {
        width: '80%',
        left: '15%',
        top: Platform.OS === 'android' ? '-2.9%' : '-1.9%',
        fontSize: 20,
        textAlign: 'justify',
        fontStyle: 'normal',
        fontFamily: 'Times New Roman',
        paddingBottom:5,
    },
    biblio: {
        width: '86%',
        left: '10%',
        top: Platform.OS === 'android' ? '-4.5%' : '-1.5%',
        fontSize: 20,
        textAlign: 'left',
        fontStyle: 'normal',
        fontFamily: 'Times New Roman',
        lineHeight: 30,
        paddingBottom: 5,
    }
})


export default PorQueScreen;