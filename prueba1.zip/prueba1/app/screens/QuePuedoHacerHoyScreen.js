import React from 'react';
import {ImageBackground, StyleSheet, Text, Platform, StatusBar, ScrollView, SafeAreaView, View, TouchableOpacity, Image, Dimensions} from 'react-native';
import Card from '../components/Card.js';
import { useDeviceOrientation } from '@react-native-community/hooks';

//This is AquApp's backbone: the 50 small actions/recommendations section
//Here the card component became vital to save time and resources

function QuePuedoHacerHoyScreen({navigation}) {
    const landscape = useDeviceOrientation();
    const Wwidth = Dimensions.get('window').width;
    return (
        <ImageBackground style = {styles.background} source={{uri:'https://i.postimg.cc/wMGHr5Kj/Reporta-Fuga-BG.png'}}> 
            <TouchableOpacity style = {{
                width : '33%',
                height: '15%',
                left: landscape === 'landscape' ?'4%':'5%',
                top : Platform === 'android' ? StatusBar.currentHeight: '5%',
            }}
            onPress={()=> navigation.navigate("Origen")}>
            <Image 
            style = {{
                width: landscape === 'landscape' ? '50%' : '90%',
                height : landscape === 'landscape' ? Wwidth*0.35*0.35: Wwidth*0.35*0.8,
                }}
                source = {{uri: 'https://i.postimg.cc/bvdtkGfc/Return-Arrow.png'}}/>
            </TouchableOpacity>
            <View style = {{
                height : landscape === 'landscape' ? '25%': '18%', 
                width: '60%',
                top : '-11%',
                left: '35%',
                backgroundColor: '#66CCFF',
                borderWidth: 8,
                borderColor: '#000099',
                padding: 5
                }}>
                <Text style= {{
                    fontSize: 20,
                }}>Todas estas acciones son el cambio pequeño que detonará las transformaciones grandes</Text>    
                </View>
            <View style = {styles.main}>
            <ScrollView style = {{
                minHeight:'120%',
                top: landscape === 'landscape' ? '10%':'0%',
                }}>
            <Card
                title = 'Compra un kilo de arroz integral en vez de blanco'
                value = '1200'
                image = 'https://i.postimg.cc/768xp4KB/comida-preview-rev-1.png'
                rate = '1.5'
            />
            <Card
                title = 'Báñate en menos de 5 minutos'
                value = '90'
                image = 'https://i.postimg.cc/XNQZXBhb/regadera-preview-rev-1-2.png'
            />
            <Card
                title = 'Usa el agua de la regadera	para el WC'
                value = '11'
                image = 'https://i.postimg.cc/sxKsQhs8/ba-o-preview-rev-1.png'
            />
            <Card
                title = 'No le jales si solo es orina'
                value = '11'
                image = 'https://i.postimg.cc/sxKsQhs8/ba-o-preview-rev-1.png'
            />
            <Card
                title = 'No descongeles con agua, déjalo fuera la noche previa'
                value = '33'
                image = 'https://i.postimg.cc/HLFhHL0D/grifo-preview-rev-1-2-1.png'
            />
            <Card
                title = 'Reemplaza una planta decorativa normal por un cactus'
                value = '10'
                image = 'https://i.postimg.cc/J4FP8G9n/regar-preview-rev-1.png'
            />
            <Card
                title = 'Implementa un sistema de captación de agua'
                value = '4900'
                image = 'https://i.postimg.cc/4x04QVVR/lluvia-preview-rev-1.png'
            />
            <Card
                title = 'Reporta una fuga pequeña'
                value = '10000'
                image = 'https://i.postimg.cc/Xvbs8Tv0/fuga-preview-rev-1-2.png'
            />
            <Card
                title = 'Reporta una fuga mediana'
                value = "1000000"
                image = 'https://i.postimg.cc/Xvbs8Tv0/fuga-preview-rev-1-2.png'
            />
            <Card
                title = 'Reporta una fuga grande'
                value = "5000000"
                image = 'https://i.postimg.cc/Xvbs8Tv0/fuga-preview-rev-1-2.png'
            />
            <Card
                title = 'Arregla una gotera'
                value = '5110'
                image = 'https://i.postimg.cc/Xvbs8Tv0/fuga-preview-rev-1-2.png'
            />
            <Card
                title = 'Primero enjabona y luego enjuaga los platos'
                value = '30'
                image = 'https://i.postimg.cc/HLFhHL0D/grifo-preview-rev-1-2-1.png'
            />
            <Card
                title = 'Compra un litro menos de leche (1L de leche requiere 600L de agua)'
                value = '600'
                image = 'https://i.postimg.cc/768xp4KB/comida-preview-rev-1.png'
            />
            <Card
                title = 'Compra un rastrillo permanente'
                value = '360'
                image = 'https://i.postimg.cc/j5xK07JN/droplet.png'
            />
            <Card
                title = 'Compra unos pantalones usados'
                value = '2500'
                image = 'https://i.postimg.cc/y8ZWd88n/usados-preview-rev-1-1-1.png'
            />
            <Card
                title = 'Hoy no uses el coche'
                value = '40'
                image = 'https://i.postimg.cc/j5xK07JN/droplet.png'
            />
            <Card
                title = 'Recicla tu bolsa de plástico'
                value = '4'
                image = 'https://i.postimg.cc/j5xK07JN/droplet.png'
            />
            <Card
                title = 'Recicla tu botella de plástico'
                value = '4'
                image = 'https://i.postimg.cc/j5xK07JN/droplet.png'
            />
            <Card
                title = 'Usa un termo y no compres agua embotellada'
                value = '1500'
                image = 'https://i.postimg.cc/768xp4KB/comida-preview-rev-1.png'
            />
            <Card
                title = 'Cómprate unos jeans de segunda mano en lugar de unos nuevos'
                value = '2500'
                image = 'https://i.postimg.cc/y8ZWd88n/usados-preview-rev-1-1-1.png'
            />
            <Card
                title = 'Dona una camiseta'
                value = '2700'
                image = 'https://i.postimg.cc/y8ZWd88n/usados-preview-rev-1-1-1.png'
            />
            <Card
                title = 'Dona un "outfit" completo'
                value = '5000'
                image = 'https://i.postimg.cc/y8ZWd88n/usados-preview-rev-1-1-1.png'
            />
            <Card
                title = 'Toma 1 litro de agua en vez de refresco'
                value = '2.5'
                image = 'https://i.postimg.cc/768xp4KB/comida-preview-rev-1.png'
            />
            <Card
                title = 'Tómate una cerveza menos'
                value = '4'
                image = 'https://i.postimg.cc/768xp4KB/comida-preview-rev-1.png'
            />
            <Card
                title = 'Toma una taza menos de café'
                value = '140'
                image = 'https://i.postimg.cc/768xp4KB/comida-preview-rev-1.png'
            />
            <Card
                title = 'Cierra el grifo al lavarte los dientes'
                value = '19'
                image = 'https://i.postimg.cc/HLFhHL0D/grifo-preview-rev-1-2-1.png'
            />
            <Card
                title = 'Compra una docena menos de huevos'
                value = '1900'
                image = 'https://i.postimg.cc/768xp4KB/comida-preview-rev-1.png'
            />
            <Card
                title = 'Dona unos jeans de algodón'
                value = '10900'
                image = 'https://i.postimg.cc/y8ZWd88n/usados-preview-rev-1-1-1.png'
            />
            <Card
                title = 'Usa una bolsa de tela y reemplaza las de plástico'
                value = '920'
                image = 'https://i.postimg.cc/j5xK07JN/droplet.png'
            />
            <Card
                title = 'Reemplaza tu inodoro tradicional por uno de bajo flujo'
                value = '6570'
                image = 'https://i.postimg.cc/sxKsQhs8/ba-o-preview-rev-1.png'
            />
            <Card
                title = 'Reemplaza tu regadera tradicional por una de bajo flujo'
                value = '30000'
                image = 'https://i.postimg.cc/XNQZXBhb/regadera-preview-rev-1-2.png'
            />
            <Card
                title = 'Reemplaza un paquete de pan blanco por pan de grano'
                value = '300'
                image = 'https://i.postimg.cc/768xp4KB/comida-preview-rev-1.png'
            />
            <Card
                title = 'Regresa tu botella de vidrio al vendedor'
                value = '2'
                image = 'https://i.postimg.cc/768xp4KB/comida-preview-rev-1.png'
            />
            <Card
                title = 'Recicla o imprime a doble cara 1 hoja de papel.'
                value = '10'
                image = 'https://i.postimg.cc/j5xK07JN/droplet.png'
            />
            <Card
                title = 'Recicla o imprime a doble cara 10 hojas de papel'
                value = '100'
                image = 'https://i.postimg.cc/j5xK07JN/droplet.png'
            />
            <Card
                title = 'Recicla o imprime a doble cara 100 hojas de papel'
                value = '1000'
                image = 'https://i.postimg.cc/j5xK07JN/droplet.png'
            />
            <Card
                title = 'Lava el auto con cubeta y no en un autolavado'
                value = '450'
                image = 'https://i.postimg.cc/j5xK07JN/droplet.png'
            />
            <Card
                title = 'Repara una fuga en tu inodoro'
                value = '200000'
                image = 'https://i.postimg.cc/Xvbs8Tv0/fuga-preview-rev-1-2.png'
            />
            <Card
                title = 'Compra un costal menos de croquetas (15kg)'
                value = '18500'
                image = 'https://i.postimg.cc/j5xK07JN/droplet.png'
            />
            <Card
                title = 'Dona unos pantalones'
                value = '2500'
                image = 'https://i.postimg.cc/y8ZWd88n/usados-preview-rev-1-1-1.png'
            />
            <Card
                title = 'Compra un kilo menos de carne de res'
                value = '15000'
                image = 'https://i.postimg.cc/768xp4KB/comida-preview-rev-1.png'
            />
            <Card
                title = 'Compra un kilo de pollo menos'
                value = '4300'
                image = 'https://i.postimg.cc/768xp4KB/comida-preview-rev-1.png'
            />
            <Card
                title = 'Compra un kilo menos de carne de puerco'
                value = '6000'
                image = 'https://i.postimg.cc/768xp4KB/comida-preview-rev-1.png'
            />
            <Card
                title = 'Compra un litro menos de coca'
                value = '69'
                image = 'https://i.postimg.cc/768xp4KB/comida-preview-rev-1.png'
            />
            <Card
                title = 'Manda una carga de ropa menos a la lavandería'
                value = '50'
                image = 'https://i.postimg.cc/j5xK07JN/droplet.png'
            />
            <Card
                title = 'Dona unos tenis'
                value = '4400'
                image = 'https://i.postimg.cc/y8ZWd88n/usados-preview-rev-1-1-1.png'
            />
            <Card
                title = 'Dona unos pantalones'
                value = '2500'
                image = 'https://i.postimg.cc/y8ZWd88n/usados-preview-rev-1-1-1.png'
            />
            <Card
                title = 'Compra unos tenis usados'
                value = '2200'
                image = 'https://i.postimg.cc/y8ZWd88n/usados-preview-rev-1-1-1.png'
            />
            <Card
                title = 'Dona unos calcetines'
                value = '2200'
                image = 'https://i.postimg.cc/y8ZWd88n/usados-preview-rev-1-1-1.png'
            />
            <Card
                title = 'Riega un jardín de 5 m^2 en la noche'
                value = '15'
                image = 'https://i.postimg.cc/J4FP8G9n/regar-preview-rev-1.png'
            />
            <Card
                title = 'Riega un jardín de 10 m^2 en la noche'
                value = '30'
                image = 'https://i.postimg.cc/J4FP8G9n/regar-preview-rev-1.png'
            />
            <Card
                title = 'Riega un jardín de 20 m^2 en la noche'
                value = '60'
                image = 'https://i.postimg.cc/J4FP8G9n/regar-preview-rev-1.png'
            />
            <Card
                title = 'Riega un jardín de 50 m^2 en la noche'
                value = '150'
                image = 'https://i.postimg.cc/J4FP8G9n/regar-preview-rev-1.png'
            />
            <Card
                title = 'Repara la fuga de tu regadera'
                value = '11000'
                image = 'https://i.postimg.cc/XNQZXBhb/regadera-preview-rev-1-2.png'
            />
            </ScrollView>
            </View>   
        </ImageBackground>
    );
}

const styles = StyleSheet.create({
    background:{
        flex: 1,
        paddingLeft: 6,
        paddingRight: 4,
        height: '100%',
    },
    main:{
        flex: 1,
        paddingLeft: 6,
        paddingRight: 4,
        top: '-10%',
        height: '90%',
        marginBottom: 35,
    },
    intro: {
        flex: 1,
        width: 70,
        height: 20,
        top: '-400%',
        left: '52%',
        backgroundColor: 'red',
    }
})

export default QuePuedoHacerHoyScreen;

