import React, { useState, useEffect } from 'react';
import { ImageBackground, StyleSheet, TouchableOpacity, Image, StatusBar, Platform, Text, View, Dimensions} from 'react-native';
import {fetchUserScore} from '../../firebaseConfig';
import { useDeviceOrientation } from '@react-native-community/hooks';

//This is the screen where it reports the total volume of water saved by all the users

function ComunidadScreen({navigation}) {
    const [score, setScore] = useState(null);
    const [error, setError] = useState(null);
    const WHeight = Dimensions.get('window').height;
    const landscape = useDeviceOrientation();

    useEffect(() => {
        const fetchScore = async () => {
            try {
                const scoreString = await fetchUserScore();
                setScore(scoreString);
            } catch (err) {
                setError(err.message);
            }
        };

        fetchScore();
    }, []);
    return (
        <ImageBackground style = {styles.background} source={{uri:'https://i.postimg.cc/wMGHr5Kj/Reporta-Fuga-BG.png'}}>
        <TouchableOpacity style = {{
                width : landscape === 'landscape' ? '15%': '33%',
                height: landscape === 'landscape' ? '30%':'15%',
                left: landscape === 'landscape' ? '5%':'2%',
                top : Platform === 'android' ? StatusBar.currentHeight: '5%',
            }}
            onPress={()=> navigation.navigate("Origen")}
            onLayout={event => {
                const layout = event.nativeEvent.layout;
                console.log('height:', layout.height);
                console.log('width:', layout.width);
                console.log('x:', layout.x);
                console.log('y:', layout.y);
              }}>
            <Image style = {{
                height : '100%'
                }}
                source = {{uri: 'https://i.postimg.cc/bvdtkGfc/Return-Arrow.png'}}/>
        </TouchableOpacity>
        <Image style = {{
            height: landscape === 'landscape' ? '60%':'30%',
            width: landscape === 'landscape' ? WHeight*0.6*(295/243) : WHeight*0.3*(295/243),
            top: landscape === 'landscape' ? '-25%':'15%',
            right: landscape === 'landscape' ?  Platform.OS === 'android' ? '-30%':'-35%': Platform.OS === 'android' ? '-16%':'-10%',
        }}
        source = {{uri: 'https://i.postimg.cc/HxYBPWdT/Comunidad.png'}}/>
        <Text style= {{
            left: landscape === 'landscape' ?  Platform.OS === 'android' ? '25%': '32.5%': Platform.OS === 'android' ? '1%':'5%',
            top : landscape === 'landscape' ? '-25%':'17%',
            color: '#003F67',
            fontSize:  Platform.OS === 'android' ? 50 :  50,
        }}>{'Hemos ahorrado'}</Text>
        <Text style = {{
                position: Platform.OS === 'android' ? 'absolute' : 'relative',
                left: landscape === 'landscape' ?  Platform.OS === 'android' ? '22%':'30%': '20%',
                top : landscape === 'landscape' ?  Platform.OS === 'android' ? '78%':'-25%': Platform.OS === 'android' ? '74%' : '20%',
                color: '#0093C1',
                fontSize:  Platform.OS === 'android' ? 60 : 60,
            }}>{error ? `Error: ${error}` : score !== null ? `${score}` : 'Loading...'}</Text>
        <Text style= {{
            left: landscape === 'landscape' ?  Platform.OS === 'android' ? '65%':'60%':'33%',
            top : landscape === 'landscape' ?  Platform.OS === 'android' ? '-30%':'-43%': Platform.OS === 'android' ? '30%' : '20%',
            color: '#3DBFEA',
            fontSize: 60,
        }}>{'Litros'}</Text>
        <View style = {{
            position: Platform.OS === 'android' ? 'absolute' : 'absolute',
            width: landscape === 'landscape' ? Platform.OS === 'android' ? WHeight*0.18*(13/3) : WHeight*0.18*(11/3) : Platform.OS === 'android' ? WHeight*0.1*(12/3) : WHeight*0.1*(10/3),
            height: landscape === 'landscape' ? Platform.OS === 'android' ? '18%':'18%': Platform.OS === 'android' ? '11%':'10%',
            right: landscape === 'landscape' ? Platform.OS === 'android'?'38%':'41%' : Platform.OS === 'android'?'17%':'12%',
            top: Platform.OS === 'android' ? landscape === 'landscape'?'80%':'75%': landscape === 'landscape' ? '80%' : '71.5%', 
            borderRadius: 20,
            borderWidth: 8,
            borderColor: '#000099',
        }}></View>
        </ImageBackground>
        
        
    );
}


const styles = StyleSheet.create({
    background: {
        flex: 1,
        //justifyContent: 'center',
        //alignItems: 'center' 
    },
})

export default ComunidadScreen;