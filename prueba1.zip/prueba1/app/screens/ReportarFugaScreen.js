import React from 'react';
import { ImageBackground, StyleSheet, View, Platform, Image, Text, SafeAreaView, Dimensions, TouchableOpacity, StatusBar, ScrollView} from 'react-native';
import { useDeviceOrientation } from '@react-native-community/hooks';

//This is the screen that provides information to report leaks

function ReportarFugaScreen({navigation}) {
    const landscape = useDeviceOrientation();
    const Wwidth = Dimensions.get('window').width;
    return (
        <ImageBackground style = {styles.fondo} source={{uri:'https://i.postimg.cc/wMGHr5Kj/Reporta-Fuga-BG.png'}} >
            
            <TouchableOpacity style = {{
                width : landscape === 'landscape' ? '20%':'33%',
                height: landscape === 'landscape' ? '30%':'15%',
                left: landscape === 'landscape' ? '4%':'2%',
                top : Platform === 'android' ? StatusBar.currentHeight: '5%',
            }}
            onPress={()=> navigation.navigate("Origen")}>
            <Image style = {{
                height : '100%'
                }}
                source = {{uri: 'https://i.postimg.cc/bvdtkGfc/Return-Arrow.png'}}/>
            </TouchableOpacity>
            <ScrollView style = {{
                flex:1,
                height: '100%',
                top: '10%',
                left: landscape === 'landscape' ? '10%': 0,
                width: landscape === 'landscape' ? '60%':'100%',
            }}>
            <Text style = {{
              top: landscape === 'landscape' ? '10%' :'5%',
              left: landscape === 'landscape' ? '5%' : '3%',
              fontSize:60, 
              color: '#000066'
            }}>
                Contactos:</Text>
            <Text style = {{
              top: '10%',
              left: landscape === 'landscape' ? '8%' : '6%',
              fontSize:40, 
              color: '#000099'
            }}>
                SACMEX:</Text>
            <Text style = {{
              top: '10%',
              left: landscape === 'landscape' ? '16%' : '12%',
              fontSize:40, 
              color: '#3333CC'
            }}>
                ╔ 55 5654 3210</Text>
            <Text style = {{
              top: '15%',
              left: landscape === 'landscape' ? '8%' : '6%',
              fontSize:40, 
              color: '#000099'
            }}>
                Locatel:</Text>
            <Text style = {{
              top: '15.5%',
              left: landscape === 'landscape' ? '16%' : '12%',
              fontSize:40, 
              color: '#3333CC',
              paddingBottom: 30
            }}>
                ╔ 55 5658 1111</Text>
                <Text style = {{
              top: '15.5%',
              left: landscape === 'landscape' ? '8%' : '6%',
              fontSize:40, 
              paddingBottom: 20,
              color: '#000099',
            }}>
                Necesitas:</Text>
                <Text style = {{
              top: '15.5%',
              left: landscape === 'landscape' ? '16%' : '12%',
              fontSize:30, 
              paddingBottom: 10,
              color: '#3333CC',
            }}>
                # Dirección</Text>
                <Text style = {{
              top: '15.5%',
              width: '70%',
              left: landscape === 'landscape' ? '16%' : '12%',
              fontSize:30, 
              color: '#3333CC',
              paddingBottom: 220,
            }}>
                # Proporción de la fuga</Text>
            </ScrollView>
        </ImageBackground>
    );
}

const styles = StyleSheet.create({
    fondo: {
        flex: 1,
        backgroundColor: "#99CCFF"
    },


})
export default ReportarFugaScreen;