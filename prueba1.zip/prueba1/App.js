import React, {useEffect} from 'react';
//import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, TouchableOpacity, Image, Alert, SafeAreaView, Button, Platform, StatusBar, Dimension} from 'react-native';

import WelcomeScreen from './app/screens/WelcomeScreen.js';
import ReportarFugaScreen from './app/screens/ReportarFugaScreen.js';
import QuePuedoHacerHoyScreen from './app/screens/QuePuedoHacerHoyScreen.js';
import PorQueScreen from './app/screens/PorQueScreen.js';
import ComunidadScreen from './app/screens/ComunidadScreen.js';

import {scoring, writeUserData} from './firebaseConfig.js'

import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { NavigationContainer } from '@react-navigation/native';

// This is the App.js where the navigation was programmed and where I wrote my first lines of code experimenting with Alert's and etc. 

//This is the navigation programming
const Stack = createNativeStackNavigator();
const StackNavigator = () => (
  <Stack.Navigator initialRouteName='Origen'>
    <Stack.Screen name = "Origen" component = {WelcomeScreen}
    options = {{
      headerShown: false,
    }}/>
    <Stack.Screen name = "Actuar" component = {QuePuedoHacerHoyScreen}
    options = {{
      headerShown: false,
    }}/>
    <Stack.Screen name = "Reportar" component = {ReportarFugaScreen}
    options = {{
      headerShown: false,
    }}/>
    <Stack.Screen name = "Informar" component = {PorQueScreen}
    options = {{
      headerShown: false,
    }}/>
    <Stack.Screen name = "Contemplar" component = {ComunidadScreen}
    options = {{
      headerShown: false,
    }}/>

  </Stack.Navigator>
)

//Here is where I first wrote my initial View and Text components
export default function App() {
  return (
    <NavigationContainer>
      <StackNavigator/>
    </NavigationContainer>
  );
}

// This was my first styles component
const styles = StyleSheet.create({
  container: {
    flex: 1,
    //backgroundColor: '#dff',
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: Platform === "android" ? 0 : StatusBar.currentHeight
  },
});
